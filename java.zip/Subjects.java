/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;

/**
 *
 * @author LENOVO
 */
public class Subjects {

    private String Subj;   //Instance Variable

    public String getSubj() {
        return Subj;
    }

    public void setSubj(String Subj) {
        this.Subj = Subj;
    }

    public void computerSc() {

        ArrayList<String> Courses = new ArrayList<String>();
        Courses.add("Data Structure");
        Courses.add("OOP");
        Courses.add("DLD");
        Courses.add("Math 1");
        Courses.add("Math 2");
        Courses.add("Phy 1");
        Courses.add("Phy 2");
        System.out.println(Courses);

    }

    public void pharm() {
        ArrayList<String> pharma = new ArrayList<String>();
        pharma.add("Biology");
        pharma.add("Chemistry");
        pharma.add("physiology");
        System.out.println(pharma);
    }

    public void Alsun() {
        ArrayList<String> Lang = new ArrayList<String>();
        Lang.add("English");
        Lang.add("French");
        Lang.add("Deutsch");
        System.out.println(Lang);
    }

    public void Business() {
        ArrayList<String> Commerce = new ArrayList<String>();
        Commerce.add("Accounting");
        Commerce.add("Ecnomics");
        Commerce.add("Marketing");
        Commerce.add("BIS");
        System.out.println(Commerce);
    }

}
