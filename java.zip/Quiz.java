/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Quiz {

    private int number;
    private String Questions;
    private String AnsTeach;
    private String Question;
    private int score = 0;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getQuestions() {
        return Questions;
    }

    public void setQuestions(String Questions) {
        this.Questions = Questions;
    }

    public void createQuiz() throws IOException, ClassNotFoundException {
        ArrayList<String> Q = new ArrayList<String>();
        try (ObjectOutputStream Questionss = new ObjectOutputStream(new FileOutputStream("C:\\Binaryfiles\\QT.bin"))) {
            ObjectInputStream Ques = new ObjectInputStream(new FileInputStream("C:\\Binaryfiles\\QT.bin"));
            Questionss.writeObject(Q);
            Ques.readObject();
        }
        int num;
        System.out.println("enter the number of questions that you want");
        Scanner sc = new Scanner(System.in);
        num = sc.nextInt();

        for (int i = 0; i < num; i++) { //hna mafesh =

            System.out.println("Enter your Question with it's choices");
            System.out.print(i + 1);
            Question = sc.next();
            for (int j = 0; j < num; j++) {
                Q.add(Question);
            }
            System.out.println("Enter the answer of that question");
            AnsTeach = sc.next();
        }

        System.out.println("your Quiz Attempt is Ready!");
    }

    public void Read() throws IOException {
        try {
            FileReader reading = new FileReader("C:\\Binaryfiles\\Ques.txt");
            int i;
            while ((i = reading.read()) != -1) {
                System.out.print(i);

            }

        } catch (IOException ex) {
            System.out.println("");
        }
    }

    public void answersOfTeacher() {

    }

    public void answersOfStudents() {

    }

    public int correction() {
        return score;
    }

}
