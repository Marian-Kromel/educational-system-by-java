/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Date;

/**
 *
 * @author LENOVO
 */
public class Clock {
    private int hr, min, sec;

    Clock() {
        Date x = new Date();
        System.out.println(x.toString());
    }

    Clock(int h, int m, int s) {
        this.hr = h;
        this.min = m;
        this.sec = s;
    }

    int setClock(int hours, int minutes, int seconds) {
        {
            if (0 <= hours && hours < 24) {
                hr = hours;
            } else {
                hr = 0;
            }
            if (0 <= minutes && minutes < 60) {
                min = minutes;
            } else {
                min = 0;
            }
            if (0 <= seconds && seconds < 60) {
                sec = seconds;
            } else {
                sec = 0;
            }
        }
        return hours;
    }

    int getHours() {
        return hr;
    }

    int getMinute() {
        return min;
    }

    int getSeconds() {
        return sec;
    }

    void setSeconds() {
        sec++;

        if (sec > 59) {
            sec = 0;
            setMinute();
        }
    }

    public void setMinute() {
        min++;

        if (min > 59) {
            min = 0;
            setHours(); //increment minutes
        }
    }

    void setHours() {
        hr++;

        if (hr > 59) {
            hr = 0;
        }
    }

    void Tick() {
        this.sec += 1;
        this.min += (int) (this.sec / 60);
        this.sec = this.sec % 60;
        this.hr += (int) (this.min / 60);
        this.min = this.min % 60;
        this.hr = this.hr % 24;
    }

    void TickDown() {
        this.sec -= 1;
        if (this.sec < 0) {
            this.sec += 60;
            this.min -= 1;
        }
        if (this.min < 0) {
            this.min += 60;
            this.hr -= 1;
        }
        if (this.hr < 0) {
            this.hr += 24;
        }
    }

    public void addClock(Clock secondClock) {
        this.sec += secondClock.getSeconds();
        this.min += secondClock.getMinute();
        this.min += (int) (this.sec / 60);
        this.sec = this.sec % 60;
        this.hr += secondClock.getHours();
        this.hr += (int) (this.min / 60);
        this.min = this.min % 60;
        this.hr = this.hr % 24;
    }

    
}
