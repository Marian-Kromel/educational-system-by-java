/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Dean extends UserLogin {

    File MyFile;
    private String DeanNAME;
    private String DeanEMAIL;
    private String DeanPASS;
    ArrayList<Teacher> teachersData = new ArrayList<>();
   

    public String getDeanNAME() {
        return DeanNAME;
    }

    public void setDeanNAME(String DeanNAME) {
        this.DeanNAME = DeanNAME;
    }

    public String getDeanEMAIL() {
        return DeanEMAIL;
    }

    public void setDeanEMAIL(String DeanEMAIL) {
        this.DeanEMAIL = DeanEMAIL;
    }

    public String getDeanPASS() {
        return DeanPASS;
    }

    public void setDeanPASS(String DeanPASS) {
        this.DeanPASS = DeanPASS;
    }

    public ArrayList<Teacher> Read(String address) throws FileNotFoundException, IOException, ClassNotFoundException {
        ArrayList<Teacher> mydata = new ArrayList<>();
        MyFile = new File(address);
        MyFile.createNewFile(); //3shan law mwgood y3ml create lwhad

        FileInputStream myFile = new FileInputStream(address);
        ObjectInputStream NF = new ObjectInputStream(myFile);
        mydata = (ArrayList<Teacher>) NF.readObject(); //casting
        NF.close();

        return mydata;
    }

    public void Write(ArrayList<Teacher> data, String path) throws IOException {
        MyFile = new File(path);
        MyFile.createNewFile();
        try {
            FileOutputStream myfile = new FileOutputStream(MyFile);
            try (ObjectOutputStream in = new ObjectOutputStream(myfile)) {
                in.writeObject(data);
                in.close();
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void readteacher() throws IOException, ClassNotFoundException { //read data
        teachersData = Read("Teachers.bin");
        for (Teacher teacher : teachersData) {
            System.out.println("Teacher name:" + teacher.getName());
            System.out.println("Teacher ID" + teacher.getId());
        }
    }

    public void addT() throws IOException, ClassNotFoundException {
        Teacher T = new Teacher();
        ArrayList<Teacher> data = Read("Teachers.bin");
        System.out.println("Enter Teacher Name: ");
        T.setName(new Scanner(System.in).next());
        System.out.println("Enter Teacher ID: ");
        T.setId(new Scanner(System.in).nextInt());
        data.add(T);
        Write(data, "Teachers.bin");
    }

    public void RemoveT() throws IOException, ClassNotFoundException {
        int id;
        Scanner in = new Scanner(System.in);
        readteacher(); //calling
        System.out.println("Enter Id of the teacher you want to remove: ");
        id = in.nextInt();

        for (int i = 0; i <= teachersData.size(); i++) {
            if (teachersData.get(i).getId() == id) {
                teachersData.remove(i);
                break;
            }
        }
        Write(teachersData, "Teachers.bin");
    }

}
