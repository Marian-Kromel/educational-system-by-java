/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;

public class Faculty extends Subjects {

    private String Fac;

    public String getFac() {
        return Fac;
    }

    public void setFac(String Fac) {
        this.Fac = Fac;
    }

    public void Faculties() {
        ArrayList<String> faculty = new ArrayList<>();
        faculty.add("Pharmacy");
        faculty.add("CS");
        faculty.add("Alsun");
        faculty.add("Business");
        System.out.println(faculty);
    }
}
