/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Timer;
import java.util.TimerTask;

public class Time {

    Timer timer;

    public Time(int seconds) {
        timer = new Timer();
        timer.schedule(new RemindTask(), seconds * 1000);
        int min = seconds * 60;
    }

    class RemindTask extends TimerTask {

        public void run() {
            System.out.println("Time's up!");
            timer.cancel();  //Terminate the timer thread
        }
    }
}
