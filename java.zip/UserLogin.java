/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import static java.lang.System.exit;
import java.util.ArrayList;
import java.util.Scanner;

public class UserLogin {

    private String usmail;  //username
    private String password;
    private String name;
    private int id;
    private String age;

    public String getUsmail() {
        return usmail;
    }

    public void setUsmail(String usmail) {
        this.usmail = usmail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void Write() throws FileNotFoundException, IOException, ClassNotFoundException {
        Quiz q = new Quiz();
        Dean A = new Dean();
        ArrayList<String> ST = new ArrayList<>();
        ArrayList<String> T = new ArrayList<>();
        try (ObjectOutputStream LogIn = new ObjectOutputStream(new FileOutputStream("C:\\Binaryfiles\\Login.bin"))) {
            ObjectInputStream Log = new ObjectInputStream(new FileInputStream("C:\\Binaryfiles\\Login.bin"));
            LogIn.writeObject(T);
            LogIn.writeObject(ST);
        }

        String admin = "Admin@kareem";
        T.add("Ashraf@Doctor.DR");
        T.add("Randa@Doctor.DR");
        T.add("Walaa@Doctor.DR");
        T.add("Gannat@Doctor.DR");
        T.add("Huda@Doctor.DR");
        ST.add("Ahmed@student.PH");
        ST.add("Mohamed@student.PH");
        ST.add("youssef@student.CS");
        ST.add("Yasmin@student.CS");
        ST.add("Salma@student.CS");
        ST.add("Miriam@student.BS");
        ST.add("Rogina@student.BS");
        ST.add("Omar@student.BS");
        ST.add("Youmna@student.BS");
        ST.add("Karam@student.Alsun");
        ST.add("Yasser@student.Alsun");
        Scanner in = new Scanner(System.in);
        String Subj;
        System.out.println("Enter user name: ");
        String user = in.next();
        Subjects sub = new Subjects();
        Faculty F = new Faculty();

        if (admin.contains(user)) {
            System.out.println("choose 1 to add teachers , 2 to remove teachers");
            int choice;
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    A.addT();
                    A.readteacher();
                    break;

                case 2:
                    A.RemoveT();
                    break;
            }

        } else if (T.contains(user)) {
            System.out.println("Enter password: ");
            String pass = in.next();
            for (String element : T) {
                if (element.contains("DR")) {
                    System.out.println("Enter faculty: ");
                    F.Faculties();
                    String faculty = in.next();
                    System.out.println("Enter your course");
                    String temp = faculty;
                    switch (temp) {
                        case "Pharmacy":
                            sub.pharm();
                            break;
                        case "CS":
                            sub.computerSc();
                            break;
                        case "Alsun":
                            sub.Alsun();
                            break;
                        case "Business":
                            sub.Business();
                            break;
                    }
                    String course = in.next();
                    q.createQuiz();
                }
                break;
            }

        } else if (ST.contains(user)) {
            System.out.println("Enter password: ");
            String pass = in.next();
            for (String SElement : ST) {
                if (SElement.contains("student")) {
                    if (SElement.contains("CS")) {
                        sub.computerSc();
                        System.out.println("Choose your subject");
                        Subj = in.next();

                    } else if (SElement.contains("BS")) {
                        sub.Business();
                        System.out.println("Choose your subject");
                        Subj = in.next();

                    } else if (SElement.contains("Alsun")) {
                        sub.Alsun();
                        System.out.println("Choose your subject");
                        Subj = in.next();

                    }

                }
                break;
            }
            System.out.println("You are logged in");
        } else {
            System.out.println("you are not allowed to access");
            exit(0);

        }
    }
}
