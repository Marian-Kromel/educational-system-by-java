/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Students extends UserLogin {

    Students() {
        //Constructor
    }

    public void Writes() throws IOException {

        ArrayList<String> stu = new ArrayList<>();
        Scanner in = new Scanner(System.in);
        ObjectOutputStream s = new ObjectOutputStream(new FileOutputStream("C:\\Binaryfiles\\StudentAnswer.bin"));
        s.writeObject(stu);
        ObjectInputStream st = new ObjectInputStream(new FileInputStream("C:\\Binaryfiles\\StudentAnswer.bin"));
        String StudentAnswer;
        System.out.println("\n Enter your choice: ");
        StudentAnswer = in.next();
        stu.add(StudentAnswer);
    }

}
