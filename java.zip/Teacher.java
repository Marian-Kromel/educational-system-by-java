/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Teacher extends UserLogin {

    private int number;
    private String Teachercourse;
    String choice;
    String Questions;
    String correction;
    char start = 'A';

    public void write() throws IOException {
        try {
            Teacher t = new Teacher();
            PrintWriter pw = new PrintWriter(new FileWriter("C:\\OOP FILES\\QT.txt"));  //create file questions
            PrintWriter pp = new PrintWriter(new FileWriter("C:\\OOP FILES\\AT.txt"));  //create file answers
            Scanner in = new Scanner(System.in);
            int number = t.getNumber();

            System.out.println("Enter, how many Question the Quiz will be:");  //3dad kam so2al?
            number = in.nextInt();

            for (int i = 1; i <= number; i++) {
                System.out.println("Enter Question" + (i) + " : "); //hydkhl el Question
                Questions = in.next();
                System.out.println();

                pw.write(Questions); //store questions in file
                //  pw.println();

                System.out.println("Enter Question type: (MCQ) PRESS (M), (T/F) PRESS T");
                char type = in.next().charAt(0);

                if (type == 'M' || type == 'm') {
                    for (int j = 1; j <= 4; j++) { //choices
                        System.out.println("Enter choice: " + " " + start++ + " : "); //a ,b ,c ,d
                        choice = in.next();
                        pw.println();
                        pw.print("Choice" + j + " : ");
                        pw.write(j + " " + choice);
                        pw.println();
                    }
                    System.out.println("Enter the correct answer: "); //ans C msln
                    correction = in.next();
                    pw.println();
                    pp.write(i + " " + correction);
                    pw.println();
                } else if (type == 'T' || type == 't') {
                    for (int j = 1; j <= 2; j++) { //choices: true false
                        System.out.println("Enter choice: " + " " + j + " : ");  //a , b
                        choice = in.next();

                        pw.println();
                        System.out.println();
                        pw.println("Choice" + j + " : ");
                        pw.write(j + " " + choice);
                        pw.println();
                    }
                    System.out.println("Enter the correct answer: "); //ans C msln
                    correction = in.next();
                    pw.println();
                    pp.write(i + " " + correction);
                    pp.println();
                }

            }
            pw.close();
            pp.close();
            System.out.println("NOW, YOU QUIZ ATTEMP IS READY !");
        } catch (Exception ex) {
            System.out.println("ERROR");
        }
    }

    public void Read() throws IOException {
        try {
            FileReader reading = new FileReader("E:\\QT.txt");
            int i;
            while ((i = reading.read()) != -1) {
                System.out.print((char) i);
            }

        } catch (Exception ex) {
            System.out.println("");
        }
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getTeachercourse() {
        return Teachercourse;
    }

    public void setTeachercourse(String Teachercourse) {
        this.Teachercourse = Teachercourse;
    }

    void add(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
